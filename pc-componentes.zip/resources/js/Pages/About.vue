<template>
  <div>
    <inertia-link href="/">Home</inertia-link>

    About
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>