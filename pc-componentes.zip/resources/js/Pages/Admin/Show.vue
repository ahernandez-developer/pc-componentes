<template>
  <div>
    <inertia-link href="/">Home</inertia-link>
    ASDF About
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>